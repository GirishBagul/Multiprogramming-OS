#include <iostream>
#include <fstream>
#include <cstdlib>
#include <cstring>
#include <ctime>
#include <vector>

using namespace std;

char M[300][4];
char IR[5];
char R[4];
int IC;
int C;
int SI;

struct PCB {
    char JID[4];
    int TTL;
    int TLL;
};

PCB info;
int flag = 0;
int currentLine;
int TTC;
int LLC;
int PI;
int TI;

int PTR;

int generated_number[100];
int generated_no_index;
int Program_card_couter;
int memoryCount = 0;

int key[30];
int value[30];
int key_index;

int gen_address;
int message;
char str[100];

int T;

int Allocate() {
    srand(time(NULL));
    int address;
    int l = 0;
    while (true) {
        address = rand() % 30;
        for (int i = 0; i <= generated_no_index; i++) {
            if (generated_number[i] == address) {
                l = 1;
                break;
            }
        }
        if (l == 0) {
            break;
        } else {
            l = 0;
        }
    }

    generated_no_index++;
    generated_number[generated_no_index] = address;

    return address;
}

void print_generated_no() {
    cout << "\n\nGenerated numbers:\n";
    for (int i = 0; i <= generated_no_index; i++) {
        cout << generated_number[i] << " ";
    }
    cout << "\n\n";
}

void print_memory_block() {
    cout << "MEMLOC | MEMORY" << endl;
    for (int i = 0; i < 300; i++) {
        cout <<setw(6) << i << " | ";
        for (int j = 0; j < 4; j++) {
            cout <<M[i][j];
        }
        if (i % 10 == 9)    cout << "\n";
        cout << "\n";
    }
}

void print_instruction_register() {
    for (int i = 0; i < 4; i++) {
        cout << IR[i];
    }
    cout << "\n";
}

void print_general_purpose_register() {
    for (int i = 0; i < 4; i++) {
        cout << R[i];
    }
    cout << "\n";
}

int Address_Map(int IC) {
    if (IC % 10 == 0 && IC != 0) {
        memoryCount++;
    }
    int address = (M[PTR + memoryCount][2] - '0') * 10 + (M[PTR + memoryCount][3] - '0');
    address = address * 10 + IC % 10;
    return address;
}
void MOS();

int map(int add) {
    if (IR[0] == 'H' && IR[1] == ' ' && IR[2] == ' ' && IR[3] == ' ')
        return 0;

    if (IR[0] == 'B' && IR[1] == 'T')
        return 0;

    if (IR[2] - '0' < 0 || IR[2] - '0' > 9 || IR[3] - '0' < 0 || IR[3] - '0' > 9) {
        PI = 2;
        MOS();
        return 0;
    }

    for (int i = 0; i <= key_index; i++) {
        if (key[i] == (add / 10) * 10) {
            return (value[i]) * 10 + add % 10;
        }
    }

    PI = 3;
    MOS();
    return 0;
}

void Terminate(int msg) {
    T = 1;

    fstream fout("Output_phase2.txt", ios::app);
    fout << "\nJob ID: " << info.JID << "\n";

    switch (msg) {
    case 0: fout << "  No Error\n"; break;
    case 1: fout << "  OUT OF DATA \n"; break;
    case 2: fout << "  LINE LIMIT EXCEEDED \n"; break;
    case 3: fout << "  TIME LIMIT EXCEEDED \n"; break;
    case 4: fout << "  OPERATION CODE ERROR \n"; break;
    case 5: fout << "  OPERAND ERROR  \n"; break;
    case 6: fout << "  INVALID PAGE FAULT \n"; break;
    case 7: fout << "  TIME LIMIT EXCEEDED  And OPERATION CODE ERROR\n"; break;
    case 8: fout << "  TIME LIMIT EXCEEDED And OPERAND ERROR \n"; break;
    }
    fout << "IC : " << IC << "\n";
    fout << "IR : " << IR << "\n";
    fout << "TTC : " << TTC << "\n";
    fout << "TTL : " << info.TTL << "\n";
    fout << "LLC : " << LLC << "\n";
    fout << "TLL : " << info.TLL << "\n\n";
}

void print_map() {
    cout << "\nMap:\n";
    for (int i = 0; i <= key_index; i++) {
        cout << key[i] << "  " << value[i] << "\n";
    }
    cout << "\n\n";
}

void EXECUTE_USER_PROGRAM();

void INIT();
void EXECUTE();
void simulation();
void Read();
void Write();
// void Terminate(0);
// void LR();
// void SR();
// void BT();
// void CR();

void Load() {
    int i = 0;
    fstream fin("Input_phase2.txt");
    if (!fin.is_open()) {
        cerr << "Can't open input file!" << endl;
        exit(1);
    }

    while (fin.getline(str, 41)) {
        if (strncmp(str, "$AMJ", 4) == 0) {

            PTR = Allocate() * 10;
            strncpy(info.JID, str + 4, 4);
            info.TTL = (str[8] - '0') * 1000 + (str[9] - '0') * 100 + (str[10] - '0') * 10 + (str[11] - '0');
            info.TLL = (str[12] - '0') * 1000 + (str[13] - '0') * 100 + (str[14] - '0') * 10 + (str[15] - '0');

            for (int i = PTR; i < PTR + 10; i++) {
                M[i][0] = '0';
                M[i][2] = '*';
                M[i][3] = '*';
            }

            cout << "AMJ found!!\n";
            cout << "Job Id  is " << info.JID << "\n";
            cout << "Total Time Limit is " << info.TTL << "\n";
            cout << "Total Line Limit is " << info.TLL << "\n\n\n";
            cout << "Page table Register is " << PTR << "\n";

            int col = 0;
            int temp, temp1;

            while (true) {
                fin.getline(str, 100);
                if (strncmp(str, "$DTA", 4) == 0)
                    break;
                temp = Allocate();
                temp1 = temp * 10;
                M[PTR + Program_card_couter][0] = '1';
                M[PTR + Program_card_couter][3] = temp % 10 + '0';
                M[PTR + Program_card_couter][2] = temp / 10 + '0';
                Program_card_couter++;

                col = 0;
                for (int i = 0; i < strlen(str) - 1; i++) {
                    if (str[i] == ' ')
                        break;
                    M[temp1][col] = str[i];
                    col++;
                    if (col == 4) {
                        temp1++;
                        col = 0;
                    }
                }
            }

            currentLine = fin.tellg();
        }
        if (strncmp(str, "$DTA", 4) == 0) {
            EXECUTE();
        }
        if (strncmp(str, "$END", 4) == 0) {
            i++;
            print_memory_block();
            cout << "\n\n\nEND Job. " << i << "\n";
            cout << str << "\n";
            cin.get();

            if (message == 1) {
                fin.seekg(fin.tellg() + ios::off_type(2));
                cout << "position is " << fin.tellg() << "\n\n";
            }

            INIT();
        }
    }
}

void INIT() {
    for (int i = 0; i < 300; i++) {
        for (int j = 0; j < 4; j++) {
            M[i][j] = ' ';
        }
    }
    memset(IR, ' ', 4);
    memset(R, ' ', 4);
    IC = 0;
    SI = 0;
    C = 0;
    T = 0;
    currentLine = 0;

    TTC = 0;
    LLC = 0;
    PI = 0;
    TI = 0;
    message = 0;

    generated_no_index = -1;
    Program_card_couter = 0;
    key_index = -1;
    memoryCount = 0;
}

void EXECUTE() {
    IC = 0;
    EXECUTE_USER_PROGRAM();
}

void EXECUTE_USER_PROGRAM() {
    while (true) {
        int addr = Address_Map(IC);
        for (int i = 0; i < 4; i++) {
            IR[i] = M[addr][i];
        }
        IC++;

        simulation();
        gen_address = map((IR[2] - '0') * 10 + (IR[3] - '0'));

        if (T == 1) {
            break;
        }

        if (!((IR[0] == 'G' && IR[1] == 'D') || (IR[0] == 'P' && IR[1] == 'D') || (IR[0] == 'H' && IR[1] == ' ') || (IR[0] == 'L' && IR[1] == 'R') || (IR[0] == 'S' && IR[1] == 'R') || (IR[0] == 'C' && IR[1] == 'R') || (IR[0] == 'B' && IR[1] == 'T'))) {
            PI = 1;
            MOS();
            break;
        }

        else if (IR[0] == 'G' && IR[1] == 'D') {
            SI = 1;
            MOS();
            if (T == 1)
                break;
        }
        else if (IR[0] == 'P' && IR[1] == 'D') {
            SI = 2;
            MOS();
            if (T == 1)
                break;
        }
        else if (IR[0] == 'H' && IR[1] == ' ') {
            SI = 3;
            MOS();
            break;
        }
        else if (IR[0] == 'L' && IR[1] == 'R') {
            int row = map((IR[2] - '0') * 10 + (IR[3] - '0'));
            for (int i = 0; i < 4; i++) {
                R[i] = M[row][i];
            }
        }
        else if (IR[0] == 'S' && IR[1] == 'R') {
            int row = map((IR[2] - '0') * 10 + (IR[3] - '0'));
            for (int i = 0; i < 4; i++) {
                M[row][i] = R[i];
            }
        }
        else if (IR[0] == 'B' && IR[1] == 'T') {
            if (C == 1) {
                IC = (IR[2] - '0') * 10 + (IR[3] - '0');
                C = 0;
            }
        }
        else if (IR[0] == 'C' && IR[1] == 'R') {
            int row = map((IR[2] - '0') * 10 + (IR[3] - '0'));
            for (int i = 0; i < 4; i++) {
                if (R[i] != M[row][i]) {
                    C = 0;
                    break;
                }
                else {
                    C = 1;
                }
            }
        }
        if (TI == 2) {
            MOS();
            break;
        }
    }
}

void simulation() {
    TTC++;
    if (TTC > info.TTL) {
        TI = 2;
    }
}

void MOS() {

    if (TI == 0) {

        if (SI == 1) {
            Read();
        }
        else if (SI == 2) {
            Write();
        }
        else if (SI == 3) {
            Terminate(0);
        }
        else if (PI == 1) {
            Terminate(4);
        }
        else if (PI == 2) {
            Terminate(5);
        }
        else if (PI == 3) {

            if ((IR[0] == 'G' && IR[1] == 'D') || (IR[0] == 'S' && IR[1] == 'R')) {

                key_index++;
                key[key_index] = (IR[2] - '0') * 10 + (IR[3] - '0');
                value[key_index] = Allocate();
                int temp = value[key_index];

                M[PTR + Program_card_couter][0] = '1';
                M[PTR + Program_card_couter][3] = temp % 10 + '0';
                M[PTR + Program_card_couter][2] = temp / 10 + '0';
                Program_card_couter++;
                PI = 0;
                return;
            } else {
                Terminate(6);
            }
        }
    }
    else if (TI == 2) {
        if (SI == 1){
            Terminate(3);
        }
        else if(SI == 2){
            Write();
            Terminate(3);
        }
        else if(SI == 3){
            Terminate(0);
        }
        // if (PI == 0) {

        //     if (IR[0] == 'P' && IR[1] == 'D') {
        //         Write();
        //     }
        //     else if (IR[0] == 'H' && IR[1] == ' ') {
        //         Terminate(0);
        //         return;
        //     }
        //     Terminate(3);
        // }

        else if (PI == 1) {
            Terminate(7);
        }
        else if (PI == 2) {
            Terminate(8);
        }
        else if (PI == 3) {
            Terminate(3);
        }
    }
}

void Read() {

    int row = map((IR[2] - '0') * 10 + (IR[3] - '0'));

    int col = 0;

    fstream fin("Input_phase2.txt");
    fin.seekg(currentLine, ios::beg);
    fin.getline(str, 100);
    if (strncmp(str, "$END", 4) == 0) {

        message = 1;
        Terminate(1);
        return;
    }
    for (int i = 0; i < strlen(str) - 1; i++) {
        M[row][col] = str[i];
        col++;
        if (col == 4) {
            row++;
            col = 0;
        }
    }
    currentLine = fin.tellg();
    SI = 0;
}

void Write() {
    LLC++;
    if (LLC > info.TLL) {
        Terminate(2);
        return;
    }

    fstream fout("Output_phase2.txt", ios::app);

    if (flag == 0)
        flag++;
    else
        fout << "\n";

    int row = map((IR[2] - '0') * 10 + (IR[3] - '0'));

    for (int i = row; i < row + 10; i++) {
        for (int j = 0; j < 4; j++) {
            fout << M[i][j];
        }
    }
    SI = 0;
}

// void Terminate(0) {
//     Terminate(0);
// }

// void LR() {
//     int row = map((IR[2] - '0') * 10 + (IR[3] - '0'));
//     for (int i = 0; i < 4; i++) {
//         R[i] = M[row][i];
//     }
// }

// void SR() {
//     int row = map((IR[2] - '0') * 10 + (IR[3] - '0'));
//     for (int i = 0; i < 4; i++) {
//         M[row][i] = R[i];
//     }
// }

// void BT() {
//     if (C == 1) {
//         IC = (IR[2] - '0') * 10 + (IR[3] - '0');
//         C = 0;
//     }
// }

// void CR() {
//     int row = map((IR[2] - '0') * 10 + (IR[3] - '0'));

//     for (int i = 0; i < 4; i++) {
//         if (R[i] != M[row][i]) {
//             C = 0;
//             break;
//         }
//         else {
//             C = 1;
//         }
//     }
// }

int main() {
    fstream f("Input_phase2.txt");
    char ch;
    if (!f.is_open()) {
        cout << "File not found!!" << endl;
        exit(1);
    }
    f.close();

    cout << "\n\n\nEnter any key to continue\n\n" << endl;
    cin.get();

    INIT();

    Load();

    return 0;
}
o
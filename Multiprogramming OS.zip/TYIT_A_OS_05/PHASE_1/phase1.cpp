#include <iostream>
#include <vector>
#include <fstream>
#include <iomanip>

using namespace std;

string IPFILE = "Input_phase1.txt";

char Memory[100][4];
vector<char> R(4), IR(4);
int IC = 0, SI = 3;
int input_ptr = 0, output_ptr = 0;
bool C = false;
string buffer = "";

void print_mem()
{
    cout << "\n\nMEMLOC| MEMORY\n";
    cout << "------| -------" << endl;
    for (int i = 0; i < 100; i++)
    {
        cout << setw(4) << i << "  |  ";
        for (int k = 0; k < 4; k++)
        {
            cout << Memory[i][k] << " ";
        }
        cout << endl;
    }
}

void clearContents()
{
    for (int i = 0; i < 100; i++)
    {
        for (int j = 0; j < 4; j++)
        {
            Memory[i][j] = '_';
        }
    }
    buffer.clear();
    R.clear();
    IC = 0;
    C = false;
}

void lineReader(string temp)
{
    fstream fout;
    fout.open("output_phase1.txt");
    fout.seekg(0, ios::end);
    fout << temp;
    fout << "\n";
    fout.close();
}

void READ(int block)
{
    cout << "\nGD" << endl;

    fstream fin;
    string line;
    fin.open(IPFILE, ios::in);
    for (int i = 0; i < input_ptr; i++)
    {
        getline(fin, line);
    }
    getline(fin, line);
    input_ptr++;
    fin.close();

    buffer = line;
    for (int i = 0; i < buffer.size() && i < 40; i++)
    {
        int a = i / 4 + block;
        int b = i % 4;
        Memory[a][b] = buffer[i];
    }
}

void WRITE(int block)
{
    cout << "\nPD" << endl;
    string temp = "";
    int i = 0;
    while (i < 40)
    {
        int a = i / 4 + block;
        int b = i % 4;
        if (Memory[a][b] == '_')
        {
            temp.push_back(' ');
        }
        else
            temp.push_back(Memory[a][b]);
        i++;
    }

    lineReader(temp);
}

void TERMINATE(int si)
{
    fstream fout;
    fout.open("Output_phase1.txt");
    fout.seekg(0, ios::end);
    fout << "\n\n";
    fout.close();
}

void MOS(int SI)
{
    int block = ((IR[2] - '0') * 10) + (IR[3] - '0'); // Extracting block number

    switch (SI)
    {
    case 1: // If SI = 1, call READ
        READ(block);
        break;

    case 2: // If SI = 2, call WRITE
        WRITE(block);
        break;

    case 3: // If SI = 3, call TERMINATE
        TERMINATE(SI);
        cout << "\nProgram Terminated.\n";
        break;

    default:
        cout << "\nInvalid SI value.\n";
        break;
    }
}

void EXECUTEUSERPROGRAM()
{

    while (1)
    {
        for (int i = 0; i < 4; i++)
        {
            IR[i] = Memory[IC][i];
        }

        IC++;

        int t1 = ((int)IR[2]) - ((int)'0');
        int t2 = ((int)IR[3]) - ((int)'0');
        int block = t1 * 10 + t2;

        if (IR[0] == 'H')
        {
            SI = 3;
            MOS(SI);
            break;
        }

        cout << "IR: " << IR[0] << " " << IR[1] << " " << IR[2] << " " << IR[3] << endl;
        cout << "Start Block: " << block << "\n\n";

        if (IR[0] == 'G' && IR[1] == 'D')
        {
            SI = 1;
            MOS(SI);
        }

        else if (IR[0] == 'P' && IR[1] == 'D')
        {
            SI = 2;
            MOS(SI);
        }

        else if (IR[0] == 'L' && IR[1] == 'R')
        {
            cout << "\n" << endl;
            for (int i = 0; i < 4; i++)
            {
                R[i] = Memory[block][i];
            }
        }

        else if (IR[0] == 'C' && IR[1] == 'R')
        {
            for (int i = 0; i < 4; i++)
            {
                if (R[i] == Memory[block][i])
                {
                    C = true;
                    break;
                }
            }
        }

        else if (IR[0] == 'S' && IR[1] == 'R')
        {
            for (int j = 0; j < 4; j++)
            {
                Memory[block][j] = R[j];
            }
        }

        else if (IR[0] == 'B' && IR[1] == 'T')
        {
            if (C == true)
            {
                IC = block;
            }
        }
    }

    cout << "\n\n #############   Program DONE   ########### \n\n";
}

void startExecution()
{
    int IC = 0;
    EXECUTEUSERPROGRAM();
}

void LOAD()
{
    fstream fin;
    string line;

    while (1)
    {
        fin.open(IPFILE, ios::in);
        for (int j = 0; j < input_ptr; j++)
        {
            getline(fin, line);
        }
        getline(fin, line);
        input_ptr++;
        fin.close();

        if (line.substr(0, 4) == "$END")
            break;

        if (line.substr(0, 4) == "$AMJ")
        {
            clearContents();

            string prog;
            fin.open(IPFILE, ios::in);
            for (int j = 0; j < input_ptr; j++)
            {
                getline(fin, prog);
            }
            getline(fin, prog);
            input_ptr++;
            cout << "Program Card: " << prog << endl;

            int k = 0;
            while (prog.substr(0, 4) != "$DTA")
            {

                for (int j = 0; j < prog.size(); j++)
                {
                    if (prog[j] == 'H')
                    {
                        Memory[k / 4][0] = 'H';
                        k += 3;
                    }
                    else
                    {
                        int a = k / 4;
                        int b = k % 4;
                        Memory[a][b] = prog[j];
                    }
                    k++;
                }

                getline(fin, prog);
                input_ptr++;
            }
            fin.close();

            startExecution();
            print_mem();
        }

        fin.open(IPFILE, ios::in);
        for (int j = 0; j < input_ptr; j++)
        {
            getline(fin, line);
        }
        getline(fin, line);
        input_ptr++;

        while (line.substr(0, 4) != "$END")
        {
            getline(fin, line);
            input_ptr++;
        }
        getline(fin, line);
    }
    fin.close();
}

int main()
{
    LOAD();
    return 0;
}